<?php

namespace App\Http\Controllers;

use App\Models\Video;
use Illuminate\Http\Request;

class VideoController extends Controller
{
    public function index()
    {
        $videos = Video::with(['user', 'product'])->latest()->get();
        return view('videos.index', compact('videos'));
    }
    
    public function show(Video $video)
    {
        // Increment view count
        $video->increment('views');
        
        // Get next video for continuous scrolling
        $nextVideo = Video::where('id', '>', $video->id)->first();
        
        return view('videos.show', compact('video', 'nextVideo'));
    }
    
    public function like(Video $video)
    {
        $video->increment('likes');
        return response()->json(['likes' => $video->likes]);
    }
}