<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Video;
use App\Models\Category;
use App\Models\User;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function __construct()
    {
        // Middleware is applied in routes file
    }

    public function dashboard()
    {
        $productsCount = Product::count();
        $videosCount = Video::count();
        $categoriesCount = Category::count();
        $usersCount = User::count();

        return view('admin.dashboard', compact('productsCount', 'videosCount', 'categoriesCount', 'usersCount'));
    }

    // Product Management
    public function products()
    {
        $products = Product::with('category')->latest()->paginate(10);
        return view('admin.products.index', compact('products'));
    }

    public function createProduct()
    {
        $categories = Category::all();
        return view('admin.products.create', compact('categories'));
    }

    public function storeProduct(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'price' => 'required|numeric',
            'category_id' => 'required|exists:categories,id',
            'stock' => 'required|integer|min:0',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $product = new Product();
        $product->name = $request->name;
        $product->description = $request->description;
        $product->price = $request->price;
        $product->category_id = $request->category_id;
        $product->stock = $request->stock;
        $product->user_id = auth()->id();

        if ($request->hasFile('image')) {
            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('images/products'), $imageName);
            $product->image_path = 'images/products/' . $imageName;
        }

        $product->save();

        return redirect()->route('admin.products.index')->with('success', 'Product created successfully');
    }

    public function editProduct($id)
    {
        $product = Product::findOrFail($id);
        $categories = Category::all();
        return view('admin.products.edit', compact('product', 'categories'));
    }

    public function updateProduct(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'price' => 'required|numeric',
            'category_id' => 'required|exists:categories,id',
            'stock' => 'required|integer|min:0',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $product = Product::findOrFail($id);
        $product->name = $request->name;
        $product->description = $request->description;
        $product->price = $request->price;
        $product->category_id = $request->category_id;
        $product->stock = $request->stock;

        if ($request->hasFile('image')) {
            // Delete old image if exists
            if ($product->image_path && file_exists(public_path($product->image_path))) {
                unlink(public_path($product->image_path));
            }
            
            $imageName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('images/products'), $imageName);
            $product->image_path = 'images/products/' . $imageName;
        }

        $product->save();

        return redirect()->route('admin.products.index')->with('success', 'Product updated successfully');
    }

    public function deleteProduct($id)
    {
        $product = Product::findOrFail($id);
        
        // Delete image if exists
        if ($product->image_path && file_exists(public_path($product->image_path))) {
            unlink(public_path($product->image_path));
        }
        
        $product->delete();

        return redirect()->route('admin.products.index')->with('success', 'Product deleted successfully');
    }

    // Video Management
    public function videos()
    {
        $videos = Video::with(['user', 'product'])->latest()->paginate(10);
        return view('admin.videos.index', compact('videos'));
    }

    public function createVideo()
    {
        $products = Product::all();
        return view('admin.videos.create', compact('products'));
    }

    public function storeVideo(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'product_id' => 'required|exists:products,id',
            'video' => 'required|mimes:mp4,mov,ogg,qt|max:20000',
            'thumbnail' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $video = new Video();
        $video->title = $request->title;
        $video->description = $request->description;
        $video->product_id = $request->product_id;
        $video->user_id = auth()->id();
        $video->views = 0;
        $video->likes = 0;

        // Handle video upload
        if ($request->hasFile('video')) {
            $videoName = time() . '.' . $request->video->extension();
            $request->video->move(public_path('videos'), $videoName);
            $video->video_path = 'videos/' . $videoName;
        }

        // Handle thumbnail upload
        if ($request->hasFile('thumbnail')) {
            $thumbnailName = time() . '_thumb.' . $request->thumbnail->extension();
            $request->thumbnail->move(public_path('videos/thumbnails'), $thumbnailName);
            $video->thumbnail_path = 'videos/thumbnails/' . $thumbnailName;
        }

        $video->save();

        return redirect()->route('admin.videos.index')->with('success', 'Video created successfully');
    }

    public function editVideo($id)
    {
        $video = Video::findOrFail($id);
        $products = Product::all();
        return view('admin.videos.edit', compact('video', 'products'));
    }

    public function updateVideo(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'product_id' => 'required|exists:products,id',
            'video' => 'nullable|mimes:mp4,mov,ogg,qt|max:20000',
            'thumbnail' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $video = Video::findOrFail($id);
        $video->title = $request->title;
        $video->description = $request->description;
        $video->product_id = $request->product_id;

        // Handle video upload
        if ($request->hasFile('video')) {
            // Delete old video if exists
            if ($video->video_path && file_exists(public_path($video->video_path))) {
                unlink(public_path($video->video_path));
            }
            
            $videoName = time() . '.' . $request->video->extension();
            $request->video->move(public_path('videos'), $videoName);
            $video->video_path = 'videos/' . $videoName;
        }

        // Handle thumbnail upload
        if ($request->hasFile('thumbnail')) {
            // Delete old thumbnail if exists
            if ($video->thumbnail_path && file_exists(public_path($video->thumbnail_path))) {
                unlink(public_path($video->thumbnail_path));
            }
            
            $thumbnailName = time() . '_thumb.' . $request->thumbnail->extension();
            $request->thumbnail->move(public_path('videos/thumbnails'), $thumbnailName);
            $video->thumbnail_path = 'videos/thumbnails/' . $thumbnailName;
        }

        $video->save();

        return redirect()->route('admin.videos.index')->with('success', 'Video updated successfully');
    }

    public function deleteVideo($id)
    {
        $video = Video::findOrFail($id);
        
        // Delete video file if exists
        if ($video->video_path && file_exists(public_path($video->video_path))) {
            unlink(public_path($video->video_path));
        }
        
        // Delete thumbnail if exists
        if ($video->thumbnail_path && file_exists(public_path($video->thumbnail_path))) {
            unlink(public_path($video->thumbnail_path));
        }
        
        $video->delete();

        return redirect()->route('admin.videos.index')->with('success', 'Video deleted successfully');
    }

    // Category Management
    public function categories()
    {
        $categories = Category::latest()->paginate(10);
        return view('admin.categories.index', compact('categories'));
    }

    public function createCategory()
    {
        return view('admin.categories.create');
    }

    public function storeCategory(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        Category::create([
            'name' => $request->name,
            'description' => $request->description,
        ]);

        return redirect()->route('admin.categories.index')->with('success', 'Category created successfully');
    }

    public function editCategory($id)
    {
        $category = Category::findOrFail($id);
        return view('admin.categories.edit', compact('category'));
    }

    public function updateCategory(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $category = Category::findOrFail($id);
        $category->name = $request->name;
        $category->description = $request->description;
        $category->save();

        return redirect()->route('admin.categories.index')->with('success', 'Category updated successfully');
    }

    public function deleteCategory($id)
    {
        $category = Category::findOrFail($id);
        
        // Check if category has products
        if ($category->products()->count() > 0) {
            return redirect()->route('admin.categories.index')->with('error', 'Cannot delete category with associated products');
        }
        
        $category->delete();

        return redirect()->route('admin.categories.index')->with('success', 'Category deleted successfully');
    }
}